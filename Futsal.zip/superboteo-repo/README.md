# Superboteo — Protótipo

Protótipo jogável de futebol de mesa (estilo Subbuteo) em HTML5 Canvas puro — sem dependências, sem build.

## Como jogar
- **1 dedo / rato**: arrasta o boneco da tua cor para trás (estilingue) e larga.
- **2 dedos** (touch): desliza na direção do chuto — a velocidade do gesto define a força.
- Marca golo passando a bola pela baliza. O placar e a vez alternam automaticamente.

## Publicar no GitHub Pages

1. Cria um repositório novo no GitHub (ex: `superboteo`).
2. Faz upload deste ficheiro `index.html` para a raiz do repositório (via GitHub web, `git push`, ou arrastando no GitHub Desktop).
3. No repositório: **Settings → Pages**.
4. Em "Source", escolhe a branch `main` e a pasta `/ (root)`. Guarda.
5. Ao fim de 1–2 minutos fica disponível em:
   `https://<o-teu-utilizador>.github.io/superboteo/`

Não precisas de servidor, build step, ou `node_modules` — é um único ficheiro estático.

## Próximos passos sugeridos
- Ligar por WebSocket (Socket.io) para dois jogadores reais em tempo real, cada um só controlando os seus bonecos.
- Contas de utilizador + histórico de vitórias/derrotas/empates em PostgreSQL.
- Ligas e torneios (tabelas de classificação, chaves eliminatórias).

## Ficheiros
- `index.html` — jogo completo (HTML + CSS + JS num único ficheiro).
